package com.payment;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.*;
import javax.servlet.http.*;

// ✅ MongoDB Imports
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class PaymentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // ✅ MongoDB database & collection names
    private static final String DB_NAME = "paymentDB";
    private static final String COLLECTION = "payments";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // ✅ Check user is logged in using session
        HttpSession session = req.getSession(false);
        String user = (session != null) ? (String) session.getAttribute("user") : null;
        if (user == null) {
            resp.sendRedirect("login.html");
            return;
        }

        // ✅ Common fields for all payments
        String method = req.getParameter("method");
        String amountStr = req.getParameter("amount");
        double amount = 0;
        String status = "FAILED";
        String reason = "";
        String idMasked = "";

        // ✅ Validate amount field
        if (amountStr == null || amountStr.trim().isEmpty()) {
            reason = "Invalid amount";
            saveToDB(user, method, idMasked, amountStr, status, reason);
            resp.sendRedirect("failure.html");
            return;
        }

        try {
            amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                reason = "Amount must be > 0";
                saveToDB(user, method, idMasked, amountStr, status, reason);
                resp.sendRedirect("failure.html");
                return;
            }
        } catch (Exception e) {
            reason = "Amount parse error";
            saveToDB(user, method, idMasked, amountStr, status, reason);
            resp.sendRedirect("failure.html");
            return;
        }

        // ✅ CARD PAYMENT VALIDATION
        if ("card".equalsIgnoreCase(method)) {
            String cardNumber = req.getParameter("cardNumber");
            String cardName = req.getParameter("cardName");
            String expiry = req.getParameter("expiry");
            String cvv = req.getParameter("cvv");

            // ✅ Check if required fields exist
            if (cardNumber == null || cardName == null || expiry == null || cvv == null
                    || cardNumber.trim().isEmpty() || cardName.trim().isEmpty()) {
                reason = "Missing card fields";
                saveToDB(user, "card", idMasked, amountStr, status, reason);
                resp.sendRedirect("failure.html");
                return;
            }

            // ✅ Remove spaces and validate number length
            String digitsOnly = cardNumber.replaceAll("\\s+", "");
            if (!digitsOnly.matches("\\d{12,19}")) {
                reason = "Card number must be 12-19 digits";
                saveToDB(user, "card", idMasked, amountStr, status, reason);
                resp.sendRedirect("failure.html");
                return;
            }

            // ✅ EXPIRY DATE CHECK (MM/YY)
            if (!isExpiryValid(expiry)) {
                reason = "Expiry invalid or past";
                saveToDB(user, "card", idMasked, amountStr, status, reason);
                resp.sendRedirect("failure.html");
                return;
            }

            // ✅ ✅ CVV VALIDATION (3-4 digits)
            if (!cvv.matches("\\d{3}")) {
                reason = "Invalid CVV";
                saveToDB(user, "card", idMasked, amountStr, status, reason);
                resp.sendRedirect("failure.html");
                return;
            }

            // ✅ LUHN Check for card number
            if (!luhnCheck(digitsOnly)) {
                reason = "Card failed Luhn check";
                saveToDB(user, "card", idMasked, amountStr, status, reason);
                resp.sendRedirect("failure.html");
                return;
            }

            // ✅ Simulated Test Rejection Rule
            if (digitsOnly.endsWith("5")) {
                reason = "Simulated decline (ends with 5)";
                idMasked = maskCard(digitsOnly);
                saveToDB(user, "card", idMasked, amountStr, status, reason);
                resp.sendRedirect("failure.html");
                return;
            }

            // ✅ SUCCESS
            status = "SUCCESS";
            idMasked = maskCard(digitsOnly);
            saveToDB(user, "card", idMasked, amountStr, status, "OK");
            resp.sendRedirect("success.html");
            return;
        }

        // ✅ UPI PAYMENT VALIDATION
        else if ("upi".equalsIgnoreCase(method)) {
            String upiId = req.getParameter("upiId");
            if (upiId == null || upiId.trim().isEmpty() || !upiId.contains("@")) {
                reason = "Invalid UPI ID";
                saveToDB(user, "upi", idMasked, amountStr, status, reason);
                resp.sendRedirect("failure.html");
                return;
            }
            idMasked = maskUPI(upiId);
            status = "SUCCESS";
            saveToDB(user, "upi", idMasked, amountStr, status, "OK");
            resp.sendRedirect("success.html");
            return;
        }

        // ✅ NET BANKING VALIDATION
        else if ("netbank".equalsIgnoreCase(method)) {
            String bank = req.getParameter("bank");
            String acc = req.getParameter("accNumber");

            if (bank == null || bank.trim().isEmpty() || acc == null || acc.trim().isEmpty()) {
                reason = "Invalid netbanking details";
                saveToDB(user, "netbank", idMasked, amountStr, status, reason);
                resp.sendRedirect("failure.html");
                return;
            }

            idMasked = maskAccount(acc);
            status = "SUCCESS";
            saveToDB(user, "netbank", idMasked, amountStr, status, "OK");
            resp.sendRedirect("success.html");
            return;
        }

        // ✅ Unknown payment method fallback
        else {
            reason = "Unknown payment method";
            saveToDB(user, method, idMasked, amountStr, status, reason);
            resp.sendRedirect("failure.html");
            return;
        }
    }

    // ✅ Save payment transaction to MongoDB
    private void saveToDB(String user, String method, String idMasked,
                          String amount, String status, String reason) {
        try (MongoClient client = MongoClients.create("mongodb://localhost:27017")) {
            MongoDatabase db = client.getDatabase(DB_NAME);
            MongoCollection<Document> col = db.getCollection(COLLECTION);

            String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

            Document doc = new Document("user", user)
                    .append("method", method)
                    .append("id", (idMasked == null ? "-" : idMasked))
                    .append("amount", amount)
                    .append("status", status)
                    .append("reason", reason)
                    .append("time", time);

            col.insertOne(doc);
        }
    }

    // ✅ CARD MASKING (Hide card digits)
    private String maskCard(String digits) {
        String last4 = digits.substring(digits.length() - 4);
        return "**** **** **** " + last4;
    }

    // ✅ UPI MASKING
    private String maskUPI(String upi) {
        int at = upi.indexOf('@');
        String local = upi.substring(0, at);
        String domain = upi.substring(at + 1);
        return local.charAt(0) + "****" + local.charAt(local.length() - 1) + "@" + domain;
    }

    // ✅ Account MASKING
    private String maskAccount(String acc) {
        return "****" + acc.substring(acc.length() - 4);
    }

    // ✅ Luhn Algorithm (Credit card validation)
    private boolean luhnCheck(String number) {
        int sum = 0;
        boolean alt = false;
        for (int i = number.length() - 1; i >= 0; i--) {
            int n = Integer.parseInt(number.substring(i, i + 1));
            if (alt) {
                n *= 2;
                if (n > 9) n = (n % 10) + 1;
            }
            sum += n;
            alt = !alt;
        }
        return (sum % 10 == 0);
    }

    // ✅ Validate expiry date properly
    private boolean isExpiryValid(String expiry) {
        try {
            String[] p = expiry.split("/");
            int mm = Integer.parseInt(p[0]);
            int yy = Integer.parseInt(p[1]);

            if (mm < 1 || mm > 12) return false;

            java.util.Calendar now = java.util.Calendar.getInstance();
            int cy = now.get(java.util.Calendar.YEAR) % 100;
            int cm = now.get(java.util.Calendar.MONTH) + 1;

            return (yy > cy || (yy == cy && mm >= cm));
        } catch (Exception e) {
            return false;
        }
    }
}
