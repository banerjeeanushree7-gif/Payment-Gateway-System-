package com.payment;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Simple hardcoded credentials for now (change later)
    private static final String USER_EMAIL = "test@user.com";
    private static final String USER_PASS  = "12345";

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        String pass  = req.getParameter("password");

        if (email != null && pass != null && email.equals(USER_EMAIL) && pass.equals(USER_PASS)) {
            HttpSession session = req.getSession();
            session.setAttribute("user", email);
            resp.sendRedirect("paymentOptions.html");
        } else {
            // You can redirect to login with error param or display message
            resp.sendRedirect("login.html?error=1");
        }
    }
}
