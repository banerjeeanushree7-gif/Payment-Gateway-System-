package com.payment;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import com.mongodb.client.*;
import org.bson.Document;

public class HistoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);
        String user = (session != null) ? (String) session.getAttribute("user") : null;

        if (user == null) {
            resp.sendRedirect("login.html");
            return;
        }

        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        out.println("<html><head><title>Payment History</title>");
        out.println("<style>");
        out.println("table { width: 80%; margin: auto; border-collapse: collapse; }");
        out.println("th, td { padding: 10px; border: 1px solid #444; text-align: center; }");
        out.println("th { background-color: #4CAF50; color: white; }");
        out.println(".success { color: green; font-weight: bold; }");
        out.println(".failed { color: red; font-weight: bold; }");
        out.println("</style></head><body>");
        out.println("<h2 style='text-align:center;'>Your Payment History</h2>");

        MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase db = mongoClient.getDatabase("paymentDB");
        MongoCollection<Document> collection = db.getCollection("payments");

        FindIterable<Document> docs = collection.find(new Document("user", user));

        out.println("<table>");
        out.println("<tr><th>Method</th><th>ID</th><th>Amount</th><th>Status</th><th>Time</th></tr>");

        for (Document doc : docs) {
            String status = doc.getString("status");
            String statusClass = status.equals("SUCCESS") ? "success" : "failed";

            out.println("<tr>");
            out.println("<td>" + doc.getString("method") + "</td>");
            out.println("<td>" + doc.getString("id") + "</td>");
            out.println("<td>" + doc.getString("amount") + "</td>");
            out.println("<td class='" + statusClass + "'>" + status + "</td>");
            out.println("<td>" + doc.getString("time") + "</td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("<br><div style='text-align:center;'><a href='paymentOptions.html'>Back to Payment Options</a></div>");
        out.println("</body></html>");
        mongoClient.close();
    }
}
